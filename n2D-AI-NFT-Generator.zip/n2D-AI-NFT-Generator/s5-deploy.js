const ethers = require('ethers');
const { network, nftamount, startonKey, signer, name, description } = require('./configuration');
const fs = require('fs');
const fsp = require("fs").promises;
const axios = require('axios');

const log = `
 █▀▄ ██▀ █▀▄ █   ▄▀▄ ▀▄▀ █ █▄ █ ▄▀    ▄▀▀ ▄▀▄ █▄ █ ▀█▀ █▀▄ ▄▀▄ ▄▀▀ ▀█▀
 █▄▀ █▄▄ █▀  █▄▄ ▀▄▀  █  █ █ ▀█ ▀▄█   ▀▄▄ ▀▄▀ █ ▀█  █  █▀▄ █▀█ ▀▄▄  █ 

`
const confirmFiles = async (dir) => {
  let amount = fs.readdirSync(dir);
  return amount.length;
}

const deploy = async (abi, bytecode) => {
  const http = axios.create({
    baseURL: "https://api.starton.io/",
    headers: {
      "x-api-key": startonKey,
    },
  });
  const send = http
    .post("v3/smart-contract/from-bytecode", {
      network: network,
      name: name,
      params: [],
      abi: abi,
      bytecode: bytecode,
      compilerVersion: "string",
      signerWallet: signer,
    })
    .then((response) => {
      return response.data
    });
    return send
};


async function deployContract(picCid) {
  let compiled = require(`./build/Collection.json`);
  const metapath = "./nftmeta/";
  const picpath = "./nftpics/";
  const metaamount = await confirmFiles(metapath);
  const picamount = await confirmFiles(picpath);
  if (metaamount == nftamount && picamount == nftamount) {
    console.log("");
    console.log(log);
    console.log(`\nDeploying NFT Collection in ${network}...`);
    let tx = await deploy(compiled.abi, compiled.bytecode);
    if (tx) {
      let nftaddress = tx.smartContract.address;
      const readTemplate = await fsp.readFile("./site-template.txt", "utf-8", function (contents) {
        return Buffer.from(contents);
      });
      let replaceFirst = readTemplate.replace(/NFT_COLLECTION_NAME/g, name);
      let replaceSecond = replaceFirst.replace(/NFT_DESC/g, description);
      let replaceThird = replaceSecond.replace(/NFT_AMOUNT/g, nftamount);
      let replaceFourth = replaceThird.replace(/NFT_ADDRESS/g, nftaddress);
      let replaceFinal = replaceFourth.replace(/NFT_CID/g, picCid);
      await fsp.writeFile("./site/mintsite.html", replaceFinal, "utf-8", function (err) {
      });
      console.log('');
      console.log('Contract Compiled Successfully.')
      console.log('')
      console.log("Contract deployed: "+ tx.smartContract.address);
      console.log('')
      console.log('Completed!')
    }
  }
}

module.exports = { deployContract };
