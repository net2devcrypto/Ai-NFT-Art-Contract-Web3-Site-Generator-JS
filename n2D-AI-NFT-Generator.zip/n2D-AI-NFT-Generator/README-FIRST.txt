IMPORTANT!

READ BEFORE PROCEEDING

N2D Ai Image + NFT Contract Generator is provided for free and is intended 
for general informational purposes only. The creators of this 
application make no representations or warranties of any kind, 
express or implied, about the completeness, accuracy, reliability, 
suitability, or availability of the application or the information, 
products, services, or related graphics contained in the application 
for any purpose. Any reliance you place on such information is therefore
strictly at your own risk. In no event will we (Net2Dev - Starton - OpenAi) 
be held liable for any loss or damage including without limitation, 
indirect or consequential loss or damage, or any loss or damage whatsoever
arising from loss of data or profits arising out of, or in
connection with, the use of this application. Through this
application, you may be able to link to other websites or
applications which are not under the control of the creators of this
application. We have no control over the nature, content, and
availability of those sites. The inclusion of any links does not
necessarily imply a recommendation or endorse the views expressed
within them. If you use this application you are in agreements to the 
terms and conditions specified.

STEPS

1- Install NodeJS

   https://nodejs.org/dist/v18.16.0/node-v18.16.0-x64.msi


1- Open your CMD, navigate to the app folder and install all dependencies:

   cd n2D-AI-NFT-GENERATOR
   npm i

2- attributes.js 

    This file contains the properties to add to the nfts. These propertis will be passed
    to OpenAI and images will be generated based on it. Each NFT will randomly obtain 
    an property from each category. You may modify each property inside but not the 
    variable itself unless you understand that you need to update any reference to the 
    variable with the new name across all applicable JS code files. 
    Save when finished: CTRL + S

3- configuration.js

   This is the main configuration file that includes all parameters needed to successfully
   generate and auto deploy your NFT Collection. Please populate with all required info.
   Save when finished: CTRL + S


4- When finished populating the configuration.js file with required info, you can 
   deploy by calling the execute.js NodeJS script.

   node execute.js


5- After the execution has been completed, Your Mint Site HTML file is ready in the "site" folder.

NOTE!

- If you want to re-execute the generator, please navigate to the folders and delete the files
specified below ONLY before re-executing:

 In the "contracts" folder: Delete "nftcollection.sol".
 In the "nftmeta" folder: Delete all files inside the folder.
 In the "nftpics" folder: Delete all files inside the folder.
 In the "site" folder: Delete "mintsite.html"




