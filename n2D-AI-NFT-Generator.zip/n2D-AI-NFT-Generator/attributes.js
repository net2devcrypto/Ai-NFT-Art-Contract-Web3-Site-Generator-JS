const faceColor = [
    "Blue",
    "Green",
    "Yellow",
    "Red",
    "Purple",
    "Pink"
];

const jeweleryStyle = [
    "Diamonds",
    "Emeralds",
    "Rubies",
    "Gold",
    "Silver",
    "Pearls"
];

const jacketStyle = [
    "Leather",
    "Jeans",
    "Silk",
    "Sports",
    "Slim",
    "Thick"
];

module.exports = { faceColor, jeweleryStyle, jacketStyle };

