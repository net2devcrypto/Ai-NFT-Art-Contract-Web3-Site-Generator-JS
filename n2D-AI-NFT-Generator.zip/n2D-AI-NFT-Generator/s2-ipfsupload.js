const axios = require("axios")
const FormData = require("form-data")
const fs = require("fs")
const { startonKey } = require('./configuration');
const { generateContract } = require('./s3-contractbuild');

const ipfslogo = `
▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄
██ ▄▄▄ █▄ ▄█ ▄▄▀█ ▄▄▀█▄ ▄█▀▄▄▀█ ▄▄▀███▄ ▄██ ▄▄ ██ ▄▄▄██ ▄▄▄ 
██▄▄▄▀▀██ ██ ▀▀ █ ▀▀▄██ ██ ██ █ ██ ████ ███ ▀▀ ██ ▄▄███▄▄▄▀▀
██ ▀▀▀ ██▄██▄██▄█▄█▄▄██▄███▄▄██▄██▄███▀ ▀██ █████ █████ ▀▀▀ 
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀
`

const updateMetaIpfs = async (PicIpfsCid, metapath) => {
  const files = fs.readdirSync(metapath)
  for (const file of files) {
    const number = file.split('.')[0];
    const fileData = fs.readFileSync(metapath + file, "utf-8");
    const jsonData = JSON.parse(fileData);
    jsonData["image"] = "ipfs://" + PicIpfsCid + '/' + number + ".png";
    fs.writeFileSync(metapath + file, JSON.stringify(jsonData));
  }
};

const uploadFolderToIpfs = async (folderPath, picfolder) => {
  const picCid = await sendToStarton(folderPath, picfolder);
  let metapath = "./nftmeta/";
  await updateMetaIpfs(picCid, metapath);
  let metafolder = "meta";
  let metaCid = await sendToStarton(metapath, metafolder);
  if (metaCid != undefined) {
    await generateContract(picCid, metaCid);
  }
};


const sendToStarton = async (folderPath, folderName) => {
    console.log(ipfslogo)
    console.log('Uploading ' + folderName + ' to IPFS...')
    const startonApi = axios.create({
        baseURL: "https://api.starton.io",
        headers: {
            "x-api-key": startonKey,
        },
    })
    let data = new FormData()
    const files = fs.readdirSync(folderPath)
    data.append("folderName", folderName)
    for (const file of files) {
        const buffer = fs.readFileSync(folderPath + "/" + file)
        data.append("files", buffer, file)
    }
    data.append("isSync", "true")
    try {
        const ipfsFolder = await startonApi.post("/v3/ipfs/folder", data, {
            headers: {
                "Content-type": `multipart/form-data; boundary=${data.getBoundary()}`,
            },
        });
        return ipfsFolder.data.cid;
    } catch (error) {
        console.error(error.response.data)
    }
    console.log(data)
}

module.exports = { uploadFolderToIpfs };