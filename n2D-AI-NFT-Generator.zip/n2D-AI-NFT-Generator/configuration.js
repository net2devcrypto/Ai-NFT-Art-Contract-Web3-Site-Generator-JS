/*
███╗   ██╗███████╗████████╗██████╗ ██████╗ ███████╗██╗   ██╗
████╗  ██║██╔════╝╚══██╔══╝╚════██╗██╔══██╗██╔════╝██║   ██║
██╔██╗ ██║█████╗     ██║    █████╔╝██║  ██║█████╗  ██║   ██║
██║╚██╗██║██╔══╝     ██║   ██╔═══╝ ██║  ██║██╔══╝  ╚██╗ ██╔╝
██║ ╚████║███████╗   ██║   ███████╗██████╔╝███████╗ ╚████╔╝ 
╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚══════╝╚═════╝ ╚══════╝  ╚═══╝  
Starton + OpenAI NFT Collection Generator + Deployer
*/

/* 
STEP 1

- Register in  OpenAI and obtain your account API Key.
  https://platform.openai.com

- Register in Starton and obtain your account API Key.
  https://auth.starton.io/create-account

  Then add your API keys below:
*/
const openAiKey = '';
const startonKey = '';

/* 
STEP 2
- Add your NFT Collection Details 

Example:

generate_art = 'PROVIDE THE ART DETAILS TO OPENAI TO GENERATE'
name = 'Name of NFT Collection'
symbol = "NFT TOKEN SYMBOL"
descr = 'Provide NFT Collection Description'
nftamount = 10
price = 0.05

*/

const generate_art = 'Small Dashchund Dogs Ultra-Realistic, Ultra-Colorful, 4k Resolution';
const name = 'Cute Dogs NFT Collection';
const symbol = 'CUTE';
const nftamount = 10;
const descr = 'Unique Alien Dogs from Outer Space. Each alien dog has multiple attributes. They will give you access to unlimited giveaways, VIP priority to community events and formal membership to our DAO.';
const price = 0.0005;

/*
STEP 3
- Create a signer wallet in Starton's KMS
  https://app.starton.io 
  Section: Wallet, Create Wallet on Starton's Key Management System.

  This wallet will be used to deploy the NFT smart contract to
  the testnet of your choice.

  Once you create the signer wallet, copy the wallet address and
  add below:

*/

const signer = ''

/*
STEP 4
- Add the network you wish to deploy your collection;

  Supported Networks:

  "ethereum-mainnet" 
  "ethereum-goerli" 
  "binance-mainnet" 
  "binance-testnet" 
  "polygon-mainnet" 
  "polygon-mumbai"
  "avalanche-mainnet" 
  "avalanche-fuji"

*/

const network = "polygon-mumbai";

// SAVE FILE (CTRL + S) !!!


/* 
STEP 5
When ready to deploy: 

On your terminal navigate to this folder then execute:

node execute.js

*/
const description = nftamount.toString() + ' ' + descr
module.exports = { generate_art,
  nftamount,
  openAiKey,
  price, 
  name, 
  description, 
  symbol, 
  startonKey, 
  network,
  signer
}
