const { generate_art, nftamount, openAiKey } = require('./configuration');
const { generateNft } = require('./s1-aigenerate');

async function executeBuild() {
    console.log('Starting Deployment..')
    generateNft(generate_art, nftamount, openAiKey);
}

executeBuild();