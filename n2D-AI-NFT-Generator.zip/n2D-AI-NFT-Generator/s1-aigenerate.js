const https = require("https");
const fs = require("fs");
const { Configuration, OpenAIApi } = require("openai");
const { name, description } = require('./configuration');
const { faceColor, jeweleryStyle, jacketStyle } = require('./attributes');
const { uploadFolderToIpfs } = require("./s2-ipfsupload");

async function download(url, filename, dir) {
  try {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir);
    }
    if (fs.existsSync(filename)) {
      return;
    } else {
      let request = https.get(url, function (response) {
        if (response.statusCode === 200) {
          let file = fs.createWriteStream(dir + '/' + filename);
          response.pipe(file);
        }
        request.setTimeout(12000, function () {
          request.abort();
        });
      });
    }
  } catch (err) {
    console.error(err);
  }
}

function chooseOne(attribute) {
  return attribute[parseInt(Math.random()*attribute.length)];
}

async function generateNft(
  generate_art,
  nftamount,
  openAiKey,
) {
  const configuration = new Configuration({
    apiKey: openAiKey,
  });
  const openai = new OpenAIApi(configuration);
  const logo = `
███████╗████████╗ █████╗ ██████╗ ████████╗ ██████╗ ███╗   ██╗
██╔════╝╚══██╔══╝██╔══██╗██╔══██╗╚══██╔══╝██╔═══██╗████╗  ██║
███████╗   ██║   ███████║██████╔╝   ██║   ██║   ██║██╔██╗ ██║
╚════██║   ██║   ██╔══██║██╔══██╗   ██║   ██║   ██║██║╚██╗██║
███████║   ██║   ██║  ██║██║  ██║   ██║   ╚██████╔╝██║ ╚████║
╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ╚═╝  ╚═══╝
  `
  console.log('')
  console.log(logo);
  console.log('')
  console.log('Generating OpenAi NFT Images....')
  console.log('');
  let i = 0;
  let pics = './nftpics'
  for (i; i < nftamount; i++) {
    let face = await chooseOne(faceColor);
    let jewelery = await chooseOne(jeweleryStyle);
    let jacket = await chooseOne(jacketStyle);
    let number = i + 1;
    let desc = 'NFT ID:' + number + ' Description: ' + face + ' ' +  generate_art + ' ' +
    'with ' + jewelery + ' jewelery and ' + jacket + ' jacket.';
    console.log(desc)
    let data = await openai.createImage({
      prompt: generate_art + 
      ', face color ' + face + 
      ', with ' + jewelery + ' jewelery and a ' + jacket,
      n: 1,
      size: "512x512",
    });
    let nftfile = number.toString() + '.png'
    await download(data.data.data[0].url, nftfile, pics);
    let nftmeta = JSON.stringify({
      "name": name,
      "description": description,
      "image": "ipfs://IPFS_CID_VALUE/" + number.toString() + '.png',
      "tokenId": number,
      "attributes": [
        {
          "trait_type": "Face Color",
          "value": face,
        },
        {
          "trait_type": "Jewelery",
          "value": jewelery,
        },
        {
          "trait_type": "Jacket",
          "value": jacket,
        }
      ]
    })
    let meta = './nftmeta'
    let nftjson = number.toString() + '.json'
    fs.writeFileSync(meta + '/' + nftjson, nftmeta)
  }
  await uploadFolderToIpfs(pics, 'pics');
};

module.exports = { generateNft }


