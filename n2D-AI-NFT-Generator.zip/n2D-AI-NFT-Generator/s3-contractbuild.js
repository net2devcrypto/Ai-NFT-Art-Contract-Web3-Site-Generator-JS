const fs = require("fs").promises
const {price, name, symbol, nftamount} = require('./configuration');
const { compileContract } = require('./s4-compile');

const log = `
 ▄▀  ██▀ █▄ █ ██▀ █▀▄ ▄▀▄ ▀█▀ █ █▄ █ ▄▀    ▄▀▀ █▄ ▄█ ▄▀▄ █▀▄ ▀█▀   ▄▀▀ ▄▀▄ █▄ █ ▀█▀ █▀▄ ▄▀▄ ▄▀▀ ▀█▀
 ▀▄█ █▄▄ █ ▀█ █▄▄ █▀▄ █▀█  █  █ █ ▀█ ▀▄█   ▄██ █ ▀ █ █▀█ █▀▄  █    ▀▄▄ ▀▄▀ █ ▀█  █  █▀▄ █▀█ ▀▄▄  █ 
`

async function generateContract(picCid, ipfsPath) {
  console.log('');
  console.log(log);
    const readTemplate = await fs.readFile("./contract-template.txt", "utf-8", function (contents) {
      return Buffer.from(contents);
    });
    let replaceFirst = readTemplate.replace(/NFT_COLLECTION_NAME/g, name);
    let replaceSecond = replaceFirst.replace(/NFT_COLLECTION_SYMBOL/g, symbol);
    let replaceThird = replaceSecond.replace(/NFT_COLLECTION_SUPPLY/g, nftamount);
    let replaceFourth = replaceThird.replace(/NFT_COLLECTION_PRICE/g, price);
    let replaceFinal = replaceFourth.replace(/IPFS_CID_PATH/g, "ipfs://" + ipfsPath + "/");
    await fs.writeFile("./contracts/nftcollection.sol", replaceFinal, "utf-8", function (err) {
        });
    console.log('');
    console.log('Contract Compiled Successfully.')
    compileContract(picCid);
}

module.exports = { generateContract }